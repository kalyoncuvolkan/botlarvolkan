<?php
define('APP_ROOT', dirname(__FILE__));

require_once 'config.php';

if (isset($_POST['record_id']) && isset($_POST['column_name']) && isset($_POST['new_value'])) {
    $recordId = $_POST['record_id'];
    $columnName = $_POST['column_name'];
    $newValue = $_POST['new_value'];

    // G�venlik i�in s�tun ad�n� beyaz listeyle kontrol edin
    $allowedColumns = ['CustomerId', 'StaffId', 'ServiceStart', 'ServiceEnd', 'ServiceDuration', 'Notes', 'ServiceTypes'];
    if (!in_array($columnName, $allowedColumns)) {
        die('Invalid column name');
    }

    // De�erleri uygun bi�imde d�n��t�r�n (tarih, s�re vb.)
    if ($columnName == 'ServiceStart' || $columnName == 'ServiceEnd') {
        $newValue = date('Y-m-d H:i:s', strtotime($newValue));
    } elseif ($columnName == 'ServiceDuration') {
        $newValue = (int)$newValue;
    } else {
        $newValue = htmlspecialchars($newValue, ENT_QUOTES);
    }

    $sql = "UPDATE ServiceRecords SET $columnName = ? WHERE Id = ?";
    $stmt = sqlsrv_prepare($conn, $sql, [$newValue, $recordId]);

    if (!$stmt) {
        die(print_r(sqlsrv_errors(), true));
    }

    if (sqlsrv_execute($stmt)) {
        echo "Record updated successfully";
    } else {
        die(print_r(sqlsrv_errors(), true));
    }
} else {
    die("Required POST parameters are missing");
}
?>
