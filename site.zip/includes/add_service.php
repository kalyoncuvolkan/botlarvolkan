<?php
// Veritabanı bağlantısı
define('APP_ROOT', dirname(__FILE__));

require_once "config.php";

date_default_timezone_set('Europe/Istanbul'); // Zaman dilimini Türkiye olarak ayarla

// Formdan gelen verileri alın
$CustomerId = isset($_POST['CustomerId']) ? $_POST['CustomerId'] : null;
$StaffId = isset($_POST['StaffId']) ? $_POST['StaffId'] : null;
$ServiceTypes = isset($_POST['ServiceTypes']) ? $_POST['ServiceTypes'] : null;

// Gerçek zamanı alın ve 2 saat ekleyin
$ServiceStart = date('Y-m-d H:i:s', strtotime('0 hours'));

// SQL sorgusunu hazırlayın
$sql = "INSERT INTO ServiceRecords (CustomerId, StaffId, ServiceStart, ServiceEnd, ServiceDuration, Notes, ServiceTypes) VALUES (?, ?, ?, NULL, NULL, NULL, ?)";

// Sorguyu hazırlayın ve parametreleri bağlayın
$params = array($CustomerId, $StaffId, $ServiceStart, $ServiceTypes);
$stmt = sqlsrv_prepare($conn, $sql, $params);

// Sorguyu çalıştırın
if (sqlsrv_execute($stmt)) {
    // Başarılıysa, kullanıcıyı dashboard.php'ye yönlendirin
    header("Location: dashboard.php");
} else {
    // Başarısızsa, hataları görüntüleyin
    die("Sorgu hatası:<br>" . print_r(sqlsrv_errors(), true));
}

// Veritabanı bağlantısını kapatın
sqlsrv_close($conn);

?>
