<?php
$serverName = "mssql-101881-0.cloudclusters.net,10158";
$connectionInfo = array("Database"=>"cekiliskazanan", "UID"=>"volkan", "PWD"=>"Ww31volser31*");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if($conn) {
    echo "Veritabanı bağlantısı başarılı!<br>";
} else {
    echo "Veritabanı bağlantısı başarısız.<br>";
    die(print_r(sqlsrv_errors(), true));
}

if(isset($_POST['submit'])) {
    $id = $_POST['id'];
    $dailyAmount = $_POST['dailyAmount'];

    // Veriyi güncelleme
    $updateSql = "UPDATE AffiRecords SET DailyAmount = ? WHERE Id = ?";
    $updateParams = array($dailyAmount, $id);
    $updateStmt = sqlsrv_query($conn, $updateSql, $updateParams);

    if($updateStmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    echo "Veri güncellendi!<br>";
}

if(isset($_GET['id'])) {
    $id = $_GET['id'];

    // Kaydı seçme
    $selectSql = "SELECT Id, RecordDate, DailyAmount FROM AffiRecords WHERE Id = ?";
    $selectParams = array($id);
    $selectStmt = sqlsrv_query($conn, $selectSql, $selectParams);

    if($selectStmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $row = sqlsrv_fetch_array($selectStmt, SQLSRV_FETCH_ASSOC);

    if($row !== null) {
        // Güncelleme formunu oluşturma
        echo "<form method='POST'>";
        echo "<input type='hidden' name='id' value='".$row['Id']."'>";
        echo "DailyAmount: <input type='text' name='dailyAmount' value='".$row['DailyAmount']."'><br>";
        echo "<input type='submit' name='submit' value='Güncelle'>";
        echo "</form>";
    } else {
        echo "Belirtilen koşullara uyan bir satır yok!";
    }

    sqlsrv_free_stmt($selectStmt);
}

sqlsrv_close($conn);
?>
