<?php
if (!defined('APP_ROOT')) {
    die('Access denied!');
}

$serverName = "mssql-101881-0.cloudclusters.net,10158";
$connectionInfo = array(
    "Database" => "ServiceTimes",
    "UID" => "volkan",
    "PWD" => "Ww31volser31*",
    "CharacterSet" => "UTF-8"
);

$conn = sqlsrv_connect($serverName, $connectionInfo);

if ($conn === false) {
    die("Veritabanına bağlanılamadı.<br>" . print_r(sqlsrv_errors(), true));
}
?>
