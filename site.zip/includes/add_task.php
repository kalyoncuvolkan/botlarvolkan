<?php
// Veritabanı bağlantısı
define('APP_ROOT', dirname(__FILE__));

require_once "config.php";

// Formdan gelen verileri alın
$name = $_POST['name'];
$assign = $_POST['assign'];
$startDate = $_POST['StartDate'];
$dueDate = $_POST['DueDate'];

// Tarih formatını düzeltin (varsayılan olarak YYYY-MM-DD)
$startDate = DateTime::createFromFormat('d/m/Y', $startDate)->format('Y-m-d');
$dueDate = DateTime::createFromFormat('d/m/Y', $dueDate)->format('Y-m-d');

// SQL sorgusunu hazırlayın
$sql = "INSERT INTO Tasks (TaskName, Assign, StartDate, DueDate, Status) VALUES (?, ?, ?, ?, ?)";

// Sorguyu hazırlayın ve parametreleri bağlayın
$params = array($name, $assign, $startDate, $dueDate, 'Atanan');
$stmt = sqlsrv_prepare($conn, $sql, $params);

// Sorguyu çalıştırın
if (sqlsrv_execute($stmt)) {
    // Başarılıysa, kullanıcıyı dashboard.php'ye yönlendirin
    header("Location: dashboard.php");
} else {
    // Başarısızsa, hataları görüntüleyin
    die("Sorgu hatası:<br>" . print_r(sqlsrv_errors(), true));
}

// Veritabanı bağlantısını kapatın
sqlsrv_close($conn);
?>
