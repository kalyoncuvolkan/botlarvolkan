<?php
// Veritaban� ba�lant�s�
define('APP_ROOT', dirname(__FILE__));

require_once('config.php');
$conn = sqlsrv_connect($serverName, $connectionInfo);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $task_id = $_GET['task_id'];
    $status = $_GET['status'];

    // Durumu g�ncelle
    $update_status_query = "UPDATE Tasks SET Status = ? WHERE Id = ?";
    $params = array($status, $task_id);
    $stmt = sqlsrv_query($conn, $update_status_query, $params);

    if ($stmt === false) {
        die("Durum g�ncelleme hatas�: " . print_r(sqlsrv_errors(), true));
    }

    // ��lem ba�ar�l�ysa, ba�ka bir sayfaya y�nlendirin (�r. dashboard2.php)
    header("Location: dashboard.php");
    exit;
} else {
    // GET iste�i olmayan (�r. POST) durumlar�nda 404 sayfas�na y�nlendirin veya uygun bir hata mesaj� g�sterin
    header("HTTP/1.1 404 Not Found");
    exit;
}
?>
