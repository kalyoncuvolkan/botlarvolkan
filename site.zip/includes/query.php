<?php
// Veritaban� ba�lanal�m
require_once('config.php');
$conn = sqlsrv_connect($serverName, $connectionInfo);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Sorgular� burada devam ettirebilirsiniz

if ($conn === false) {
    die("Veritaban�na ba�lan�lamad�.<br>" . print_r(sqlsrv_errors(), true));
}

$perPage = 10; // �ste�e ba�l� olarak de�i�tirilebilir

// Sayfa numaras�n� alal�m
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $perPage;

// Tamamlanmam�� ��leri getiren sorgu
$devamtasksorgu = "SELECT Tasks.Id, Tasks.TaskName, Tasks.StartDate, Tasks.DueDate, Tasks.Status, Staff.DisplayName
FROM Tasks
INNER JOIN Staff ON Tasks.Assign = Staff.StaffId
WHERE Tasks.Status <> 'Done'
ORDER BY Tasks.StartDate DESC
OFFSET ? ROWS FETCH NEXT ? ROWS ONLY;";
$params = array($offset, $perPage);
$stmt_devamtask = sqlsrv_query($conn, $devamtasksorgu, $params);

if ($stmt_devamtask === false) {
    die("Tamamlanmam�� i�ler sorgusunda hata olu�tu.<br>" . print_r(sqlsrv_errors(), true));
}



// Sorgu 2
$musteriborcsorgu = "SELECT CustomerId, CustomerName, RecordDate, Amount, Paid 
FROM CustomerReceivables
ORDER BY RecordDate DESC;";
$stmt_musteriborc = sqlsrv_query($conn, $musteriborcsorgu);

if ($stmt_musteriborc === false) {
    die("M��teri bor�lar sorgusunda hata olu�tu.<br>" . print_r(sqlsrv_errors(), true));
}

// Feriye Bakiye Sorgusu
$feriyeBakiyeSorgu = "SELECT TotalAmount FROM feriyebakiyes;"; 
$stmt_feriyeBakiye = sqlsrv_query($conn, $feriyeBakiyeSorgu);

if ($stmt_feriyeBakiye === false) {
    die("Feriye bakiye sorgusunda hata olu�tu.<br>" . print_r(sqlsrv_errors(), true));
}

// Feriye Bakiye sonucunu alal�m
$feriyeBakiyeRow = sqlsrv_fetch_array($stmt_feriyeBakiye, SQLSRV_FETCH_ASSOC);
$feriyeBakiye = $feriyeBakiyeRow['TotalAmount'];

// Emar Bakiye Sorgusu
$emarBakiyeSorgu = "SELECT TotalAmount FROM emarbakiye;"; 
$stmt_emarBakiye = sqlsrv_query($conn, $emarBakiyeSorgu);

if ($stmt_emarBakiye === false) {
    die("Emar bakiye sorgusunda hata olu�tu.<br>" . print_r(sqlsrv_errors(), true));
}

// Emar Bakiye sonucunu alal�m
$emarBakiyeRow = sqlsrv_fetch_array($stmt_emarBakiye, SQLSRV_FETCH_ASSOC);
$emarBakiye = $emarBakiyeRow['TotalAmount'];

// Fabrika Bakiye Sorgusu
$fabrikaBakiyeSorgu = "SELECT TotalAmount FROM fabrikabakiye;"; 
$stmt_fabrikaBakiye = sqlsrv_query($conn, $fabrikaBakiyeSorgu);

if ($stmt_fabrikaBakiye === false) {
    die("Fabrika bakiye sorgusunda hata olu�tu.<br>" . print_r(sqlsrv_errors(), true));
}

// Fabrika Bakiye sonucunu alal�m
$fabrikaBakiyeRow = sqlsrv_fetch_array($stmt_fabrikaBakiye, SQLSRV_FETCH_ASSOC);
$fabrikaBakiye = $fabrikaBakiyeRow['TotalAmount'];

// Kate Bakiye Sorgusu
$kateBakiyeSorgu = "SELECT TotalAmount FROM katebakiye;"; 
$stmt_kateBakiye = sqlsrv_query($conn, $kateBakiyeSorgu);

if ($stmt_kateBakiye === false) {
    die("Kate bakiye sorgusunda hata olu�tu.<br>" . print_r(sqlsrv_errors(), true));
}

// Kate Bakiye sonucunu alal�m
$kateBakiyeRow = sqlsrv_fetch_array($stmt_kateBakiye, SQLSRV_FETCH_ASSOC);
$kateBakiye = $kateBakiyeRow['TotalAmount'];


// Sayfa numaras� ve sayfadaki kay�t say�s�
$limit = 5; // �rne�in sayfada 10 kay�t
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// SQL sorgusu
$serviceRecordsSorgu = "SELECT * FROM ServiceRecords ORDER BY Id DESC OFFSET $offset ROWS FETCH NEXT $limit ROWS ONLY;";
$stmt_serviceRecords = sqlsrv_query($conn, $serviceRecordsSorgu);

// Toplam kay�t say�s�n� al�n
$countQuery = "SELECT COUNT(*) as totalCount FROM ServiceRecords;";
$stmt_count = sqlsrv_query($conn, $countQuery);
$countResult = sqlsrv_fetch_array($stmt_count, SQLSRV_FETCH_ASSOC);
$totalCount = $countResult['totalCount'];

// Toplam sayfa say�s�n� hesaplay�n
$totalPages = ceil($totalCount / $limit);



if ($stmt_serviceRecords === false) {
    die("ServiceRecords sorgusunda hata olu�tu.<br>" . print_r(sqlsrv_errors(), true));
}

function getStaffName($staffId) {
    if ($staffId == 1) {
        return "Salvo ROMI";
    } elseif ($staffId == 2) {
        return "Volkan KALYONCU";
    } else {
        return "Bilinmeyen";
    }
}

function getCustomerName($customerId) {
    if ($customerId == 1) {
        return "Feriye";
    } elseif ($customerId == 2) {
        return "Emar";
    } elseif ($customerId == 3) {
        return "Fabrika Mimarlik";
    } elseif ($customerId == 4) {
        return "Akta�";
    } elseif ($customerId == 5) {
        return "Valente Tekstil";
    } elseif ($customerId == 6) {
        return "Kate Hotel";
    } elseif ($customerId == 7) {
        return "Mors IT";
    } else {
        return "Bilinmeyen";
    }
}


function getServiceType($serviceType) {
    if ($serviceType == "Local") {
        return "Yerinde Servis";
    } elseif ($serviceType == "Remote") {
        return "Uzaktan Servis";
    } else {
        return "Bilinmeyen";
    }
}



ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Veritaban� ba�lant�s�n� KAPATMAYIN ve kaynaklar� SERBEST BIRAKMAYIN
// Bunlar dashboard.php dosyas�nda yap�lacakt�r.
?>

