<?php
define('APP_ROOT', dirname(__FILE__));

require_once('includes/config.php');

// Başlangıçta login.php dosyasının başında
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Kullanıcıdan gelen form verilerini alalım
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Veritabanına bağlanalım
    $conn = sqlsrv_connect($serverName, $connectionInfo);

    if ($conn === false) {
        // Veritabanına bağlanamazsak hata mesajı gösterelim
        die("Veritabanı bağlantısı başarısız.
<br>" . print_r(sqlsrv_errors(), true));
    }

    // Staff tablosundaki kayıtları sorgulayalım
    $sql = "SELECT * FROM Staff WHERE Email = ? AND Password = ?";
    $params = array($email, $password);
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        // Sorguda bir hata olursa hata mesajı gösterelim
        die("Sorgu hatası:
<br>" . print_r(sqlsrv_errors(), true));
    }

    if (sqlsrv_has_rows($stmt)) {
        // Staff tablosunda eşleşen bir kayıt varsa, kullanıcıyı ana sayfaya yönlendirelim
        $userData = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

        $_SESSION['loggedin'] = true;
        $_SESSION['user_id'] = $userData['StaffId'];

        header("Location: dashboard.php");
        exit;
    } else {
        // Staff tablosunda eşleşen bir kayıt yoksa, hata mesajı gösterelim ve login
        $errorMessage = "Hatalı e-posta adresi veya şifre.";
    }

    sqlsrv_free_stmt($stmt);
    sqlsrv_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Mors Bilişim CRM - Giriş Yap</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style" />
    
    <!-- icons -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
 </head>
 <body class="loading authentication-bg authentication-bg-pattern">   
     <div class="account-pages my-5">
         <div class="container">
     
             <div class="row justify-content-center">
                 <div class="col-md-8 col-lg-6 col-xl-4">
                     <div class="text-center">
                         <a href="index.html">
                             <img src="assets/images/logo-dark.png" alt="" height="22" class="mx-auto">
                         </a>
                         <p class="text-muted mt-2 mb-4">Mors Bilişim CRM v1.00</p>
     
                     </div>
                     <div class="card">
                         <div class="card-body p-4">
     
                             <div class="text-center mb-4">
                                 <h3 class="text-uppercase mt-0">Hoş Geldin Patron!</h3>
                             </div>

                              <?php if (isset($errorMessage)): ?>
                                  <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                      <?php echo $errorMessage ?>
                                  </div>
                              <?php endif; ?>
     
                             <form class="user" action="index.php" method="POST">
                                 <div class="mb-3">
                                     <label for="exampleInputEmail" class="form-label">Email Adresiniz</label>
                                     <input class="form-control form-control-user" type="email" id="exampleInputEmail" name="email" placeholder="Mail adresinizi girin">                              
                                 </div>
     
                                 <div class="mb-3">
                                     <label for="exampleInputPassword" class="form-label">Şifreniz</label>
                                     <input type="password" class="form-control form-control-user" id="exampleInputPassword" name="password" placeholder="Şifrenizi Girin">
                                      
                                 </div>
     
                                 <div class="mb-3">
                                     <div class="form-check">
                                         <input type="checkbox" class="form-check-input" id="checkbox-signin" checked>
                                         <label class="form-check-label" for="checkbox-signin">Beni Hatırla</label>
                                     </div>
                                 </div>
     
                                 <div class="mb-3 d-grid text-center">
                                     <button type="submit" class="btn btn-primary"> Giriş </button>
                                 </div>
                             </form>
     
                         </div> <!-- end card-body -->
                     </div>
                     <!-- end card -->
     
                     <div class="row mt-3">
                         <div class="col-12 text-center">
                             <p> <a href="#" class="text-muted ms-1"><i class="fa fa-lock me-1"></i>Parolanızı mı unuttunuz ?</a></p>
                             <p class="text-muted">Don't have an account? <a href="pages-register.html" class="text-dark ms-1"><b>Sign Up</b></a></p>
                         </div> <!-- end col -->
                     </div>
                     <!-- end row -->
     
                 </div> <!-- end col -->
             </div>
             <!-- end row -->
         </div>
         <!-- end container -->
     </div>
     <!-- end page -->
     <!-- Vendor -->
     <script src="assets/libs/jquery/jquery.min.js"></script>
     <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
     <script src="assets/libs/simplebar/simplebar.min.js"></script>
     <script src="assets/libs/node-waves/waves.min.js"></script>
     <script src="assets/libs/waypoints/lib/jquery.waypoints.min.js"></script>
     <script src="assets/libs/jquery.counterup/jquery.counterup.min.js"></script>
     <script src="assets/libs/feather-icons/feather.min.js"></script>
     <!-- App js -->
     <script src="assets/js/app.min.js"></script>
     </body>
     </html>